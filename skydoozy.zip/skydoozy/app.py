from flask import Flask, render_template, request, jsonify 
from flask_cors import CORS
import os
import subprocess
import random
import threading
import time

number = 0
app = Flask(__name__) 
CORS(app)
app=Flask(__name__,template_folder='.')

class Tester:
	def __init__(self):
		self.input = []
		self.output = []
		
	def testExe(self, data):
		print(data)
		process_for_division = subprocess.Popen(['BillAccept.exe', "http://qwerwq.io"], stdin=subprocess.PIPE, shell=True)
		# process_for_division = subprocess.run(['BillAccept.exe', "http://qwerwq.io"], shell=True, stdout = subprocess.PIPE, stderr = subprocess.PIPE)
		out, err = process_for_division.communicate()
		print("out::: ", out)
		print("err::: ", err)
		lines = ['Readme', 'How to write text files in Python']
		with open('readme.txt', 'w') as f:
			for line in lines:
				f.write(line)
				f.write('\n')


@app.route('/', methods= ['GET', 'POST']) 
def home():
	return str(number)
	return render_template("index.html")

@app.route('/run', methods=['POST']) 
def _shell(): 
	test = Tester()
	test.testExe('Hello')
	return jsonify({'status': 1} )


if __name__ == '__main__':
	app.run(debug=True, port=8001) 
